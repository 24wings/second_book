namespace Wings.Base.Common.DTO {

    /// <summary>
    /// DevExtream Body Datas
    /// </summary>
    public class DevExtremInput {
        /// <summary>
        /// 
        /// </summary>
        public string values { get; set; }
        /// <summary>
        /// 主键
        /// </summary>
        /// <value></value>
        public int key { get; set; }
    }
}