using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using DevExtreme.AspNet.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Wings.Base.Common.Attrivute;
using Wings.Base.Common.DTO;
using Wings.Base.Common.Services;
using Wings.Projects.Rcxh.RBAC.Entity;

namespace Wings.Projects.Video.Controllers {
    /// <summary>
    /// 组织管理
    /// </summary>
    [Route ("/api/Video/video")]
    public class VideoController {
        /// <summary>
        /// 
        /// </summary>
        public VideoController () {

        }
        /// <summary>
        /// 列出所有视频
        /// </summary>
        /// <returns></returns>
        [HttpGet ("[action]")]
        public object listVideo () {
            return OSSService.listFiles ();
        }

    }
}